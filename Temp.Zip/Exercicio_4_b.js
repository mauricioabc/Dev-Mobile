import React from 'react';
import { View, StyleSheet } from 'react-native';

const Exercicio_4 = () => {
  return (
    <View style={styles.container}>
      <View style={styles.topSquare}>
        <View style={styles.quarterRed} />
        <View style={styles.quarterBlue} />
      </View>
      <View style={styles.endSquare}>
        <View style={styles.quarterRed} />
        <View style={styles.quarterBlue} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  topSquare: {
    flexDirection: 'row-reverse',
    width: '100%',
    height: '50%',
    backgroundColor: 'white',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  endSquare: {
    flexDirection: 'column',
    width: '100%',
    height: '50%',
    backgroundColor: 'white',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  quarterRed: {
    width: 70,
    height: 70,
    backgroundColor: '#FF9999',
  },
  quarterBlue: {
    width: 70,
    height: 70,
    backgroundColor: 'blue',
  },
});

export default Exercicio_4;