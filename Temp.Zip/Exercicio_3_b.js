import React from 'react';
import { View, StyleSheet } from 'react-native';

const Exercicio_3 = () => {
  return (
    <View style={styles.container}>
      <View>
        <View style={[styles.box, { backgroundColor: '#90EE90' }]} />
      </View>
      <View>
        <View style={[styles.boxCenter, { backgroundColor: '#FF9999' }]} />
      </View>
      <View>
        <View style={[styles.box, { backgroundColor: '#ADD8E6' }]} />
        <View style={[styles.boxEnd, { backgroundColor: 'purple' }]} />
      </View>
      <View style={[styles.boxEnd, { backgroundColor: 'purple' }]} />
    </View>
  );
};
//<View style={[styles.boxEnd, { backgroundColor: 'purple' }]} />

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
  },  
  box: {
    width: 110,
    height: '50%',
  },
  boxCenter: {
    width: 70,
    height: '50%',
  },
  boxEnd: {
    width: 100,
    height: 100,
    backgroundColor: 'orange',
  },
});

export default Exercicio_3;