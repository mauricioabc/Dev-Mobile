import React from 'react';
import { View, StyleSheet } from 'react-native';

const Exercicio_2 = () => {
  return (
    <View style={styles.container}>
      <View style={styles.quarterRed} />
      <View style={styles.quarterWhite} />
      <View style={styles.quarterWhite} />
      <View style={styles.quarterBlue} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  quarterWhite: {
    width: '50%',
    height: '50%',
    backgroundColor: 'white',
  },
  quarterBlue: {
    width: '50%',
    height: 40,
    backgroundColor: '#ADD8E6',
  },
  quarterRed: {
    width: '50%',
    height: 40,
    marginTop: 280,
    backgroundColor: '#FF9999',
  },
});

export default Exercicio_2;