import React from 'react';
import { View, StyleSheet } from 'react-native';

const Exercicio_2 = () => {
  return (
    <View style={styles.container}>
      <View style={styles.redSquare} />
      <View style={styles.blueSquare} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  redSquare: {
    width: 1000,
    height: 1000,
    backgroundColor: '#ADD8E6',
  },
  blueSquare: {
    width: 1000,
    height: 1000,
    backgroundColor: '#FF9999',
  },
});

export default Exercicio_2;