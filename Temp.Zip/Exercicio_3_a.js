import React from 'react';
import { View, StyleSheet } from 'react-native';

const Exercicio_3 = () => {
  return (
    <View style={styles.container}>
      <View>
        <View style={[styles.box, { backgroundColor: '#90EE90' }]} />
      </View>
      <View>
        <View style={[styles.boxCenter, { backgroundColor: '#FF9999' }]} />
      </View>
      <View>
        <View style={[styles.box, { backgroundColor: '#ADD8E6' }]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
  },  
  box: {
    width: 110,
    height: '100%',
  },
  boxCenter: {
    width: 70,
    height: '100%',
  },
});

export default Exercicio_3;