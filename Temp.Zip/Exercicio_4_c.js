import React from 'react';
import { View, StyleSheet } from 'react-native';

const Exercicio_4 = () => {
  return (
    <View style={styles.container}>
      <View style={styles.topSquare}>
        <View style={styles.quarterRed} />
        <View style={styles.quarterBlueTop} />
      </View>
      <View style={styles.endSquare}>
        <View style={styles.quarterRed} />
        <View style={styles.quarterBlueEnd} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  topSquare: {
    flexDirection: 'row-reverse',
    width: '100%',
    height: '50%',
    backgroundColor: 'white',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  endSquare: {
    flexDirection: 'column',
    width: '100%',
    height: '50%',
    backgroundColor: 'white',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  quarterRed: {
    width: 70,
    height: 70,
    backgroundColor: '#FF9999',
  },
  quarterBlueEnd: {
    width: 70,
    height: 70,
    backgroundColor: 'blue',
    marginLeft: '80.5%',
  },
  quarterBlueTop: {
    width: 70,
    height: 70,
    backgroundColor: 'blue',
    marginTop: '70%',
  },
});

export default Exercicio_4;